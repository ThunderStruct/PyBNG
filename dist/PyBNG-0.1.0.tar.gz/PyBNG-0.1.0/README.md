# PyBNG
[![Build Status](https://travis-ci.org/ThunderStruct/PyBNG.svg?branch=master)](https://travis-ci.org/ThunderStruct/PyBNG) [![pypi](https://img.shields.io/badge/pypi%20package-0.1.0-lightgrey.svg)](https://github.com/ThunderStruct/PyBNG) [![Python](https://img.shields.io/badge/python-3.5^-blue.svg)](https://github.com/ThunderStruct/PyBNG) [![License](https://img.shields.io/cocoapods/l/AFNetworking.svg)](https://github.com/ThunderStruct/PyBNG/blob/master/LICENSE)

An Ordinance-Survey National Grid coordinates converter

------------------------


## License

This project is licensed under the MIT License - see the [LICENSE](https://github.com/ThunderStruct/PyBNG/blob/master/LICENSE) file for details


